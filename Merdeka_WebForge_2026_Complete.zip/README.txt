MERDEKA WEBFORGE 2026 — COMPLETE WEBSITE
=============================================

Files:
- index.html
- style.css
- script.js
- Images/ (optional)

HOW TO OPEN:
1. Extract this ZIP.
2. Open the folder in Visual Studio Code.
3. Open index.html.
4. Recommended: install the VS Code "Live Server" extension.
5. Right-click index.html -> "Open with Live Server".

NOTES:
- The design works without image files because the hero, flag, skyline, culture and
  decorative visuals are built with CSS.
- You can add real Malaysian photographs later inside Images/ and replace any CSS
  visual with <img> elements.
- The state search and responsive mobile menu are already functional.
